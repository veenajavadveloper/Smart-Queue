/*
 * Copyright Pinkmatter Solutions
 * www.pinkmatter.com
 */
package com.pinkmatter.hr.tests;

public interface SmartQueue<T> extends AutoCloseable {

    public void push(T item);

    public static <T> SmartQueue<T> createAsync(int maxDepth, SmartQueueMode mode, ItemHandler<T> consumer) {
        /* Implement this and return your AsyncSmartQueue implementation */
        throw new UnsupportedOperationException("Not implemented yet");
    }
}
