/*
 * Copyright Pinkmatter Solutions
 * www.pinkmatter.com
 */
package com.pinkmatter.hr.tests;

/**
 *
 * @author Chris
 */
public interface ItemHandler<T> {
    
    public void accept(T item);
    
    public void close();
    
}
