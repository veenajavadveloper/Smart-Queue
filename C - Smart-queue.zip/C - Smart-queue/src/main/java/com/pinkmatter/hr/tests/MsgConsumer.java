package com.pinkmatter.hr.tests;

import java.util.concurrent.BlockingQueue;

public class MsgConsumer extends Thread{
	
	private final BlockingQueue<AsyncSmartQueue<MyMsg>> queue;
	private int limit;

    public MsgConsumer(BlockingQueue<AsyncSmartQueue<MyMsg>> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        while(true){
            try {
            	
            	AsyncSmartQueue<MyMsg> msg = queue.take();
            	 msg.getasyncSmartQueue().handle();
            	 System.out.println(" consumer message received " + queue+" "+ toString()  ); 
               
				if (queue.size() > 5)
                	 
                	queue.remove();
				else {
					if(queue.size()>=this.limit) {
						System.out.println("limit exeeded");
						
					}
					
				}
       
                	} 
            catch (InterruptedException e) {
                e.getMessage();
            }
        }
    }

}
