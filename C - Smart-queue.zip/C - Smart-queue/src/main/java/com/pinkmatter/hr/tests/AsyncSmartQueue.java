package com.pinkmatter.hr.tests;

public class AsyncSmartQueue<T> {
	private T asyncSmartQueue;
	
	public AsyncSmartQueue(T asyncSmartQueue) {
	this.asyncSmartQueue =asyncSmartQueue;	 
	 }
	
	public void close() {
		
		System.out.println("closed");
	}
	
	 public T getasyncSmartQueue () {
	        return asyncSmartQueue;
	    }

	

	

}
