/*
 * Copyright Pinkmatter Solutions
 * www.pinkmatter.com
 */
package com.pinkmatter.hr.tests;

/**
 *
 * @author Chris
 */
public enum SmartQueueMode {
    
    Drop,
    Block
    
}
