/*
 * Copyright Pinkmatter Solutions
 * www.pinkmatter.com
 */
package com.pinkmatter.hr.tests;

/**
 *
 * @author Chris
 */
public class PrintingItemHandler<T> implements ItemHandler<T> {

    @Override
    public void accept(T msgid) {
        System.out.println("Accepted item "+msgid);
    }

    @Override
    public void close() {
        System.out.println("ItemHandler closed");
    }
    
}
