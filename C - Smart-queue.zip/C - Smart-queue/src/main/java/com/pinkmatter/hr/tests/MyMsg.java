package com.pinkmatter.hr.tests;

import java.lang.invoke.MethodHandles;
import java.util.logging.Logger;

public class MyMsg {
	
	
		private static final Logger log = Logger.getLogger(MethodHandles.lookup().lookupClass().getSimpleName());

	    private final int msgId;
	    private  int limit=10 ;

	    public MyMsg(int msgId) {
	        this.msgId = msgId;
	    }

	    public void handle() {
	        log.info("Serving event with id: " + msgId);
	        try {
	            Thread.sleep(500);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	        
	        public int block(int limit) {
		       return this.limit=limit;
				
} 


}


