package com.pinkmatter.hr.tests;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;




public class Validation {

	public static void main( String[] args ){
		    	
		    	BlockingQueue<AsyncSmartQueue<MyMsg>> queue = new ArrayBlockingQueue<AsyncSmartQueue<MyMsg>>(12);

		    	MsgProducer producer = new MsgProducer(queue);
		    	MsgConsumer consumer = new MsgConsumer(queue);

		    	producer.start();
		    	consumer.start();
		        System.out.println( "Hello World!" );
		    }
		

	}

