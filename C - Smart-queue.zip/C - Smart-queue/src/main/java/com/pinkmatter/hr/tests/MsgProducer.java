package com.pinkmatter.hr.tests;

import java.lang.invoke.MethodHandles;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

public class MsgProducer extends Thread {
		
		private final BlockingQueue<AsyncSmartQueue<MyMsg>> queue;
	    private AtomicInteger id;

	    public static final Logger log = Logger.getLogger(MethodHandles.lookup().lookupClass().getName());

	    public MsgProducer(BlockingQueue<AsyncSmartQueue<MyMsg>> queue) {
	        this.queue = queue;
	        id = new AtomicInteger();
	    }

	    @Override
	    public void run() {
	        for (int i = 0; i < 10; i++) {
	            boolean wasAdded = false;
	            MyMsg eventToAdd = new MyMsg(id.getAndIncrement());
	            try {
	                wasAdded = queue.offer(new AsyncSmartQueue<MyMsg>(eventToAdd), 100, TimeUnit.MILLISECONDS);
	            } catch (InterruptedException e) {
	                log.info("Adding Thread was interrupted");
	            } finally {
	                handleAddResult(wasAdded, eventToAdd);
	            }
	        }
	    }

		private void handleAddResult(boolean wasAdded, MyMsg eventToAdd) {
			
			System.out.println("sent from producer");
		System.out.println("sent from producer --"+ wasAdded+ eventToAdd);
			
		
			
		}
	    
	  
	}
	
	


